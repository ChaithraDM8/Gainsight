package com.gainsight.mvc.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;


@Repository
public class PassengerDao {
	String url="jdbc:mysql://localhost:3306/demo";
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	int count=0;
	
	public boolean createPassenger(String passengersId,String firstName, String lastName,  long mobile,String email)
			
	{
		
			//Passengers passengers = new Passengers(passengersId,firstName, lastName, mobile, email);
		try (Connection con = DriverManager.getConnection(url, "root", "chaithra");
	             PreparedStatement pst = con.prepareStatement("insert into passengers values(?,?,?,?,?)")) {
	            
	                pst.setString(1, passengersId);
	                pst.setString(2, firstName);
	                pst.setString(3, lastName);
	                pst.setLong(4, mobile);
	                pst.setString(5, email);
	                count = pst.executeUpdate();
	            }

	         catch (Exception e) {
	            throw new RuntimeException(e);
	        }
	        return count == 1;
	    }
			
			
	}


