package com.gainsight.mvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.gainsight.mvc.Dao.AccountDao;

@Controller
public class MoneyTransferController {
	
	@Autowired
	AccountDao accountDao;
	
	@GetMapping("/moneyTransferForm")
	public String getMoneyTransferForm() {
		return "MoneyTransferForm";
	}
	@GetMapping("/transferMoney")
	public String transferMoney(@RequestParam double amount, @CookieValue("username") String username,Model model) {
		String message="Money Transfer Failed";
		
		if(accountDao.modifyAccountBalance(username, amount)) 
			message = "Money Succesfullty Transfered";
		
		model.addAttribute("message",message);
		
		return "Display";
		
	}

}
