package com.gainsight.mvc.Dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


import org.springframework.stereotype.Repository;


@Repository
public class FlightBookingDao {

private static String url="jdbc:mysql://localhost:3306/demo";
public boolean bookTicket(String bookingId,String passengerId, String flightId,Date date) {
	int count=0;
	
	try (Connection con = DriverManager.getConnection(url, "root", "chaithra");
            PreparedStatement pst = con.prepareStatement("insert into bookings values(?,?,?,?,?)")) {
           
               pst.setString(1, bookingId);
               pst.setString(2,passengerId );
               pst.setString(3, flightId);
               pst.setDate(4, date);
              
               count = pst.executeUpdate();
           }

        catch (Exception e) {
           throw new RuntimeException(e);
       }
      
	
	return count==1;
	
	
	
	
	
}
	
}
