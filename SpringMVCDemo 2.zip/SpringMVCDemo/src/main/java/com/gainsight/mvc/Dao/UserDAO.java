package com.gainsight.mvc.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import org.springframework.stereotype.Repository;

import com.gainsight.mvc.Entity.User;

@Repository
public class UserDAO {
	private static String url="jdbc:mysql://localhost:3306/demo";
	Connection con=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	int count=0;
	public boolean validateUser(User user) {
		try {
			
		Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,"root","chaithra");
		
			pst= con.prepareStatement("select count(*) from users where username=? and password=?");
			pst.setString(1, user.getUserName());
			pst.setString(2, user.getPassword());
			rs= pst.executeQuery();
			if(rs.next()) count=rs.getInt(1);
		}
		catch(Exception e) {
		e.printStackTrace();
		}
		finally {
			try {
				if(rs!=null) rs.close();
				if(pst!=null) pst.close();
				if(con!=null) con.close();
			}
			catch(Exception e) {
				e.printStackTrace();
				}
		}
	
	return count==1;

}
}
