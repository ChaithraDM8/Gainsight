package com.gainsight.mvc.Entity;

public class Passengers {
	private String passengersId;
	private String fisrtName;
	private String lastName;
	private long mobile;
	private String email;
	
	Passengers(){}

	public Passengers(String passengersId, String fisrtName, String lastName, long mobile, String email) {
		super();
		this.passengersId = passengersId;
		this.fisrtName = fisrtName;
		this.lastName = lastName;
		this.mobile = mobile;
		this.email = email;
	}

	public String getPassengersId() {
		return passengersId;
	}

	public void setPassengersId(String passengersId) {
		this.passengersId = passengersId;
	}

	public String getFisrtName() {
		return fisrtName;
	}

	public void setFisrtName(String fisrtName) {
		this.fisrtName = fisrtName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public long getMobile() {
		return mobile;
	}

	public void setMobile(long mobile) {
		this.mobile = mobile;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}
	

}
