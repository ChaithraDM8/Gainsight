package com.gainsight.mvc.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import org.springframework.stereotype.Repository;


@Repository
public class AccountDao {
	private static String url="jdbc:mysql://localhost:3306/demo";
	
	public boolean modifyAccountBalance(String userName, double amount) {
		
		Connection con=null;
		PreparedStatement pst=null;

		
		int count=0;
		try {
			
		Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(url,"root","chaithra");
		
			pst= con.prepareStatement("update account set balance=balance-? where username=?");
			pst.setDouble(1,amount);
			pst.setString(2, userName);
			count= pst.executeUpdate();
		}
		catch(Exception e) {
		e.printStackTrace();
		}
		finally {
			try {
				if(pst!=null) pst.close();
				if(con!=null) con.close();
			}
			catch(Exception e) {
				e.printStackTrace();
				}
		}
	
	return count==1;

}

}
